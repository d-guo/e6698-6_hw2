import boto3
import inflection
import json

from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth


REGION = 'us-east-1'
HOST = 'search-photos-sowdncarwfcckgivwpirg5s4la.us-east-1.es.amazonaws.com'
INDEX = 'photos'


lex = boto3.client('lexv2-runtime')

def get_awsauth(region, service):
    cred = boto3.Session().get_credentials()
    return AWS4Auth(
        cred.access_key,
        cred.secret_key,
        region,
        service,
        session_token=cred.token
    )

os = OpenSearch(
    hosts=[
        {
            'host': HOST,
            'port': 443
        }
    ],
    http_auth=get_awsauth(REGION, 'es'),
    use_ssl=True,
    verify_certs=True,
    connection_class=RequestsHttpConnection
)


def lambda_handler(event, context):
    query = json.loads(event['body'])['query']
    
    res = lex.post_text(
        botName='lex-ass2',
        botAlias='alias-ass2',
        userId='search_photos',
        inputText=query
    )
    labels = [inflection.singularize(kw) for kw in res['slots'].values() if kw]
    print(labels)
    
    # if keywords:
    #     results = search_photos(keywords)
    # else:
    #     results = []
    
    # return {
    #     'statusCode': 200,
    #     'headers': {
    #         'Access-Control-Allow-Origin': '*'
    #     },
    #     'body': json.dumps(results)
    # }

def search_photos(keywords):
    query = {
        'query': {
            'bool': {
                'should': [
                    {'match': {'labels': keyword}} for keyword in keywords
                ]
            }
        }
    }
    
    res = os.search(index=INDEX, body=q)
    hits = res['hits']['hits']
    
    return [hit['_source'] for hit in hits]